package com.capgemini.hotelmanagement.exception;

import org.apache.log4j.Logger;

@SuppressWarnings("serial")
public class CustomerNotFoundException extends RuntimeException {

	String message;
	static final Logger log = Logger.getLogger(CustomerNotFoundException.class);

	public CustomerNotFoundException(String message) {
		this.message = message;
		log.error("\n\n" + message);
	}
}
