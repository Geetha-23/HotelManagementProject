package com.capgemini.hotelmanagement.dao;

public interface AdminLoginDao {

	public boolean adminLogin();
}
