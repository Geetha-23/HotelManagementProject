package com.capgemini.hotelmanagement.dao;

public interface AdminDao {
	public boolean listOfHotels();

	public void bookingForSpecificHotel();
	
	
    
	public void bookingForSpecificDate();

	public void operateHotelDetails();

	public void operateRoomDetails();
	
}
