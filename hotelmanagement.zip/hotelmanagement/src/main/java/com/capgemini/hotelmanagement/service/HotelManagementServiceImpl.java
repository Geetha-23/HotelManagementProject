package com.capgemini.hotelmanagement.service;

import com.capgemini.hotelmanagement.dao.HotelManagementDao;
import com.capgemini.hotelmanagement.factory.Factory;

public class HotelManagementServiceImpl implements HotelManagementService{

	public boolean hotelManagementService() {
		HotelManagementDao hotelManagement=Factory.getHotelManagementDaoImpl();
		hotelManagement.getEmployeeLogin();
		return false;
	}
	

}
