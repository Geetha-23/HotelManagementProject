package com.capgemini.hotelmanagement.bean;

public class RoomDetails {

	private int roomNumber;
	private String roomType;

	public int getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	@Override
	public String toString() {
		return "RoomDetails [roomNumber=" + roomNumber + ", roomType=" + roomType + "]";
	}
	
	}
