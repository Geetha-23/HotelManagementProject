package com.capgemini.hotelmanagement.bean;

public class Hotel {

	private String hotelName;
	private String hotelAddress;
	private int noOfRooms;
	private long contactNumber;

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getHotelAddress() {
		return hotelAddress;
	}

	public void setHotelAddress(String hotelAddress) {
		this.hotelAddress = hotelAddress;
	}

	public int getNoOfRooms() {
		return noOfRooms;
	}

	public void setNoOfRooms(int noOfRooms2) {
		this.noOfRooms = noOfRooms2;
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	@Override
	public String toString() {
		return "Hotel [hotelName=" + hotelName + ", hotelAddress=" + hotelAddress + ", noOfRooms=" + noOfRooms
				+ ", contactNumber=" + contactNumber + "]";
	}
}
