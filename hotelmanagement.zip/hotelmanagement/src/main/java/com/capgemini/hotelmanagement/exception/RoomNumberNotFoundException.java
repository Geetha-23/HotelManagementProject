package com.capgemini.hotelmanagement.exception;

public class RoomNumberNotFoundException extends Exception{
public RoomNumberNotFoundException() {
	
}
}
