package com.capgemini.hotelmanagement.factory;

import com.capgemini.hotelmanagement.validation.InputValidation;





import com.capgemini.hotelmanagement.validation.InputValidationImpl;
import com.capgemini.hotelmanagement.service.AdminService;
import com.capgemini.hotelmanagement.service.AdminServiceImpl;
import com.capgemini.hotelmanagement.service.CustomerLoginService;
import com.capgemini.hotelmanagement.service.CustomerLoginServiceImpl;
import com.capgemini.hotelmanagement.service.HotelManagementService;
import com.capgemini.hotelmanagement.service.HotelManagementServiceImpl;
import com.capgemini.hotelmanagement.bean.AdminLogin;
import com.capgemini.hotelmanagement.bean.Booking;
import com.capgemini.hotelmanagement.bean.CustomerRegistration;
import com.capgemini.hotelmanagement.bean.Hotel;

import com.capgemini.hotelmanagement.bean.HotelManagementLogin;
import com.capgemini.hotelmanagement.bean.RoomDetails;
import com.capgemini.hotelmanagement.controller.HotelController;
import com.capgemini.hotelmanagement.dao.BookingDaoImpl;
import com.capgemini.hotelmanagement.dao.AdminDaoImpl;
import com.capgemini.hotelmanagement.dao.AdminLoginDaoImpl;
import com.capgemini.hotelmanagement.dao.CustomerLoginDao;
import com.capgemini.hotelmanagement.dao.CustomerLoginDaoImpl;
import com.capgemini.hotelmanagement.dao.CustomerRegistrationDao;
import com.capgemini.hotelmanagement.dao.CustomerRegistrationDaoImpl;

import com.capgemini.hotelmanagement.dao.HotelDaoImpl;

import com.capgemini.hotelmanagement.dao.HotelManagementDaoImpl;
import com.capgemini.hotelmanagement.dao.RoomDetailsDao;
import com.capgemini.hotelmanagement.dao.RoomDetailsDaoImpl;
import com.capgemini.hotelmanagement.service.RegistrationService;
import com.capgemini.hotelmanagement.service.RegistrationServiceImpl;

public abstract class Factory {

public static CustomerRegistration getCustomerRegistration(){
		CustomerRegistration customerRegisteration = new CustomerRegistration();
		return customerRegisteration;
		
}
public static CustomerRegistrationDao getRegistrationDAOInstance() {
	CustomerRegistrationDao registerDao = new CustomerRegistrationDaoImpl();
	return registerDao;
}


	
	public static InputValidation getInputValidationInstance() {

		return new InputValidationImpl();
	}
	public static CustomerLoginDao getLoginDaoInstance() {
		CustomerLoginDao loginDao=new CustomerLoginDaoImpl();
		return loginDao;
	}
	public static AdminLoginDaoImpl getLoginDaoImplInstance() {
		return new AdminLoginDaoImpl();
	}
	

	public static AdminDaoImpl getAdminDaoImplInstance() {
		return new AdminDaoImpl();
	}	

	public static Booking getBookingInstance() {
		return new Booking();
	}

	public static BookingDaoImpl getBookingDaoImplInstance() {
		return new BookingDaoImpl();
	}

	
	public static AdminLogin getAdminInstance() {
		return new AdminLogin();
	}

	public static Hotel getHotelInstance() {
		return new Hotel();
	}

	public static HotelDaoImpl getHotelDaoImplInstance() {
		return new HotelDaoImpl();
	}

	public static RoomDetails getRoomInstance() {
		return new RoomDetails();
	}

	public static RoomDetailsDaoImpl getRoomDaoImplInstance() {
		return new RoomDetailsDaoImpl();
	}
	public static HotelController getHotelControllerInstance() {
		return new HotelController();
	}
	public static HotelManagementLogin getHotelManagementLoginInstance() {
		return new HotelManagementLogin();
	}
	public static HotelManagementDaoImpl getHotelManagementDaoImpl() {
		return new HotelManagementDaoImpl();
		
	}
	public static CustomerRegistration getCustomerRegistrationInstance() {
		return new CustomerRegistration();
	}
	public static CustomerRegistrationDao getCustomerRegistrationDAOImplementationInstance() {
		return new CustomerRegistrationDaoImpl();
	}
	public static RegistrationService getRegistrationServiceImplInstance() {
		return new RegistrationServiceImpl();
	}
	public static CustomerLoginService getCustomerLoginServiceImplInstance() {
		return new CustomerLoginServiceImpl();
	}
	public static AdminService getAdminServiceImplInstance() {
		return new AdminServiceImpl();
	}
	public static HotelManagementService getHotelManagementServiceImplInstance() {
		return new HotelManagementServiceImpl();
	}

	}



