package com.capgemini.hotelmanagement.dao;

import com.capgemini.hotelmanagement.bean.RoomDetails;

public interface RoomDetailsDao {

	public boolean addRoom();

	public boolean deleteRoom(String roomNumber);

	public boolean updateRoom(RoomDetails room);
}
