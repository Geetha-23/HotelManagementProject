package com.capgemini.hotelmanagement.dao;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.bean.Hotel;
import com.capgemini.hotelmanagement.exception.HotelNameNotFoundException;
import com.capgemini.hotelmanagement.factory.Factory;

public class HotelDaoImpl implements HotelDao {
	static final Logger log = Logger.getLogger(HotelDaoImpl.class);
	static List<Hotel> hotelList = new ArrayList<Hotel>();
	Scanner scanner = new Scanner(System.in);
	static {

		Hotel hotel = Factory.getHotelInstance();

		hotel.setHotelName("Milan Hotel");
		hotel.setHotelAddress("Mumbai, Maharashtra");
		hotel.setNoOfRooms(20);
		hotel.setContactNumber(6281296092l);

		Hotel hotel1 = Factory.getHotelInstance();

		hotel1.setHotelName("Novotel Hotel");
		hotel1.setHotelAddress("hyderabad,telangana");
		hotel1.setNoOfRooms(23);
		hotel1.setContactNumber(9700200787l);

		hotelList.add(hotel);
		hotelList.add(hotel1);

	}

	public boolean addHotel() {

		Hotel hotel = Factory.getHotelInstance();

		log.info(" Please enter hotel name");
		String hotelName = scanner.next();
		while (!Factory.getInputValidationInstance().hotelNameValidation(hotelName)) {
			log.info("Please enter valid hotel name(Hotel name must contain NameOfHotel )  ");
			hotelName = scanner.next();
		}

		log.info("Please enter hotel address");
		String hotelAddress = scanner.next();
		while (!Factory.getInputValidationInstance().hotelAddressValidation(hotelAddress)) {
			log.info("Please enter valid hotel address (Hotel name must contain City and State) ");
			hotelAddress = scanner.next();
		}

		log.info("Please enter contact number");
		String contactNumber = scanner.next();
		while (!Factory.getInputValidationInstance().hotelContactNumberValidation(contactNumber)) {
			log.info("Please enter valid contact number(Contact number must 10 digits)  ");
			contactNumber = scanner.next();
		}
		long hotelContactNumber = Long.parseLong(contactNumber);


		log.info("Please enter total number of rooms in hotel");
		String noOfRooms = scanner.next();
		while (!Factory.getInputValidationInstance().ageValidation(noOfRooms)) {
			log.info("please enter valid number of rooms");
			noOfRooms = scanner.next();
		}
		int numberOfRooms = Integer.parseInt(noOfRooms);
		hotel.setHotelName(hotelName);
		hotel.setHotelAddress(hotelAddress);
	
		hotel.setContactNumber(hotelContactNumber);

		ArrayList<Hotel> hotelList1 = new ArrayList<Hotel>();
		hotelList1.add(hotel);
		hotelList.addAll(hotelList1);
		if (hotelList1.isEmpty()) {
			log.error("hotel details are not added");
		} else {
			log.info("New  hotel details are added ");
		}
		return false;

	}

	public boolean deleteHotel(String hotelName) {
		int count = 0;
		Iterator<Hotel> hotel = hotelList.iterator();
		while (hotel.hasNext()) {
			Hotel str = hotel.next();
			if (str.getHotelName().equals(hotelName)) {
				count++;
				hotel.remove();
				log.info("*********Data deleted successfully*******");
			}

		}
		try {
			if (count == 0) {
				throw new HotelNameNotFoundException();
			}
		} catch (HotelNameNotFoundException e) {
			log.info(" hotel name not found ");
		}
		return false;
	}

	public boolean updateHotel(Hotel hotel) {

		String hotelName1 = scanner.nextLine();
		while (!Factory.getInputValidationInstance().hotelNameValidation(hotelName1)) {
			log.info("please enter valid name");
			hotelName1 = scanner.nextLine();
		}
		int count = 0;
		for (Hotel hotel1 : hotelList) {

			if (hotel1.getHotelName().equals(hotelName1)) {
				count++;
				log.info("***Request is Done*** ");
				log.info("*************** update details ***************");

				log.info("\n 1. Hotel Name \n" + " 2. Hotel Address \n" + " 3. Contact Number \n"
						+ " 4. Total number of rooms \n" + " 5. Exit \n");
				String choice = scanner.nextLine();
				while (!Factory.getInputValidationInstance().choiceUpdateHotelValidate(choice)) {
					log.info("\nPlease enter from  1 - 5 ");
					choice = scanner.nextLine();
				}
				log.info("update hotel  name");
				String hotelName2 = scanner.nextLine();
				while (!Factory.getInputValidationInstance().hotelNameValidation(hotelName2)) {
					log.info("please enter valid name(Hotel name must contain NameOfHotel )");
					hotelName2 = scanner.nextLine();
				}
				hotel1.setHotelName(hotelName2);

				log.info("update hotel address");
				String hotelAdress = scanner.nextLine();
				while (!Factory.getInputValidationInstance().hotelAddressValidation(hotelAdress)) {
					log.info("please enter valid address(Hotel name must contain City and State)");
					hotelAdress = scanner.nextLine();
				}

				hotel1.setHotelAddress(hotelAdress);

				log.info("update number of rooms");
				String numOfRooms = scanner.nextLine();

				int numberOfRooms = Integer.parseInt(numOfRooms);
				hotel1.setNoOfRooms(numberOfRooms);

				log.info("update contact number");
				String phno = scanner.nextLine();
				while (!Factory.getInputValidationInstance().hotelContactNumberValidation(phno)) {
					log.info("please enter valid contact number(Contact number must 10 digits) ");
					phno = scanner.nextLine();
				}
				long phno1 = Long.parseLong(phno);
				hotel1.setContactNumber(phno1);
			}

		}
		try {
			if (count == 0) {
				throw new HotelNameNotFoundException();

			} else {
				log.info("***************Hotel Details Updated Sucessfully***************");

			}
		} catch (HotelNameNotFoundException e) {
			log.info("Hotel Name Not Found");
		}
		return false;

	}

	public List<Hotel> getAllHotelDetails() {
		int count = 1;
		for (Hotel hotel : hotelList) {

			log.info(count + "." + hotel.getHotelName());
			count++;

		}
		return hotelList;
	}

}
