package com.capgemini.hotelmanagement.dao;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.bean.Booking;
import com.capgemini.hotelmanagement.bean.CustomerRegistration;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.validation.InputValidation;

public class CustomerLoginDaoImpl implements CustomerLoginDao {
	Logger log = Logger.getLogger(CustomerLoginDaoImpl.class);
	Scanner sc = new Scanner(System.in);
	CustomerRegistration cr = Factory.getCustomerRegistration();
	CustomerRegistrationDao customer = Factory.getRegistrationDAOInstance();
	List<CustomerRegistration> custlist = new ArrayList<CustomerRegistration>(CustomerRegistrationDaoImpl.customer);
	InputValidation inputValidation = Factory.getInputValidationInstance();

	public boolean login() {
		CustomerLoginDao customerlogindao = Factory.getLoginDaoInstance();
		InputValidation inputValidation = Factory.getInputValidationInstance();
		log.info("Enter username");
		String username = sc.next();
		while (!inputValidation.usernameValidation(username)) {
			log.info("please enter valid username");
			username = sc.next();
		}

		log.info("Enter password");
		String password = sc.next();
		while (!inputValidation.passwordValidation(password)) {
			log.info("please enter valid password");
			password = sc.next();
		}
		int count = 0;
		Iterator<CustomerRegistration> itr = custlist.iterator();

		while (itr.hasNext()) {

			CustomerRegistration customer1 = itr.next();

			if (username.equals(customer1.getUsername()) && password.equals(customer1.getPassword())) {
				count++;

			}
		}

		if (count == 0) {
			log.info("Login Fail");
			return false;
		} else {
			log.info("*****************Login successfully*********************");
			customerOperations();
			return true;
		}
		

	}

	public boolean customerOperations() {
		do {
			log.info("1.Hotel booking");
			log.info("2.Exit");
			String choice = sc.next();
			while (!Factory.getInputValidationInstance().choiceValidateCustomerOperations(choice)) {
				log.error("Please enter valid choice(It should be 1 or 2)");
				choice = sc.next();
			}

			int choice1 = Integer.parseInt(choice);

			switch (choice1) {
			case 1:
				Factory.getBookingDaoImplInstance().BookingHotel();

				break;
			case 2:
				Factory.getHotelControllerInstance().hotelManagementSystem();
				break;
		
			}
		} while (true);
	}

	

	}


