package com.capgemini.hotelmanagement.controller;

import java.util.Scanner;



import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.service.AdminService;
import com.capgemini.hotelmanagement.service.CustomerLoginService;
import com.capgemini.hotelmanagement.service.HotelManagementService;
import com.capgemini.hotelmanagement.service.RegistrationService;
import com.capgemini.hotelmanagement.validation.InputValidation;


public class HotelController {
	static final Logger log = Logger.getLogger(HotelController.class);

	static Scanner sc = new Scanner(System.in);
	
		

	public void hotelManagementSystem() {
		
		log.info("Select the options below");
	InputValidation inputValidations = Factory.getInputValidationInstance();


		 do {

			log.info("1. Customer Login");
			log.info("2. Admin Login");
			log.info("3. HotelManagemet Login");
			log.info("4. Customer Registration(new user)");
			log.info("5. Exit");
			String choice1 = sc.next();
			while (!inputValidations.choiceValidate(choice1)) {
				log.info(" enter valid choice");
				choice1 = sc.next();
			}
			int choice = Integer.parseInt(choice1);

			switch (choice) {
			case 1:
				CustomerLoginService customerLogin=Factory.getCustomerLoginServiceImplInstance();
				customerLogin.customerLginService();
				break;
			case 2:

				
				AdminService adminService=Factory.getAdminServiceImplInstance();
				adminService.adminService();
				break;
				
				
				
			case 3:
				
				HotelManagementService hotelManagementService=Factory.getHotelManagementServiceImplInstance();
				hotelManagementService.hotelManagementService();
				break;				
				case 4:
					RegistrationService registerService=Factory.getRegistrationServiceImplInstance();			
					registerService.registerService();
					break;
			case 5:
				System.exit(0);
				sc.close();
				break ;

			}
		} while (true);
		
	}
public static void main(String[] args) {
	

log.info("Hotel Booking Management System");
	Factory.getHotelControllerInstance().hotelManagementSystem();

}
		
	}

