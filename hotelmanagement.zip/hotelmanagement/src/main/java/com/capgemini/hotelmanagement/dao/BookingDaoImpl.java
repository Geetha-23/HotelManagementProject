package com.capgemini.hotelmanagement.dao;

import java.time.LocalDate;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.bean.Booking;
import com.capgemini.hotelmanagement.exception.InvalidDateException;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.validation.InputValidation;

public class BookingDaoImpl implements BookingDao {

	static final Logger log = Logger.getLogger(BookingDaoImpl.class);

	int count = 0;
	static List<Booking> bookList = new ArrayList<Booking>();

	
	Scanner sc = new Scanner(System.in);
	

	static {

		

		

		Booking booking = Factory.getBookingInstance();

	booking.setFromDate(LocalDate.of(2020, 04, 25));
	booking.setToDate(LocalDate.of(2020, 04, 27));
		booking.setName("geetha");
		booking.setHotelName("Novotel Hotel");
		booking.setAddress("vijayawada");
		booking.setEmail("srigeetha@gmail.com");
		booking.setContactNumber(9700200787l);
		booking.setRoomNum(111);
		booking.setRoomType("single");
		booking.setPaymentMethod("card Payment");

		Booking booking2 = Factory.getBookingInstance();

		booking2.setFromDate(LocalDate.of(2020,05,05));
		booking2.setToDate(LocalDate.of(2020, 05, 25));
		booking2.setName("sai123");
		booking2.setHotelName("Novotel Hotel");
		booking2.setAddress("vijayawada");
		booking2.setEmail("sai@gmail.com");
		booking2.setContactNumber(9676046365l);
		booking2.setRoomNum(123);
		booking2.setRoomType("single");
		
		booking2.setPaymentMethod("card Payment");

		bookList.add(booking);
		bookList.add(booking2);
		
	}

	public List<Booking> getBookingDetails() {

		for (int i = 0; i < bookList.size(); i++) {
			log.info("\n" + bookList.get(i));
		}
		return bookList;
	}
	
	public Booking getBookingDetailsForSpecificDate(LocalDate bookingDate) {
		int count = 0;
	for (Booking booking : bookList) {
		if (booking.getFromDate().equals(bookingDate)) {
			count++;
			List<Booking> searchBooking = new ArrayList<Booking>();
			searchBooking.add(booking);
			log.info(searchBooking);
		}
	}
	try {
		if (count == 0)
			throw new InvalidDateException();
	} catch (InvalidDateException e) {
		log.info("No Bookings in such Date");
	}

	return null;
}

public boolean addBooking(Booking booking) {

	log.info("Please enter from date(FORMAT:YYYY-MM-DD)");
	String fromdate = sc.next();
	while (!Factory.getInputValidationInstance().bookingDateValidation(fromdate)) {
		log.info("Please enter valid date(FORMAT:YYYY-MM-DD)");
		fromdate = sc.next();
	}

	LocalDate fromDate = LocalDate.parse(fromdate);
	while (fromDate.isBefore(LocalDate.now())) {
		log.info("please enter a valid Date");
		fromdate = sc.next();
		while (!Factory.getInputValidationInstance().bookingDateValidation(fromdate)) {
			log.info("Please enter valid date in the format  YYYY-MM-DD");
			fromdate = sc.next();
		}
		fromDate = LocalDate.parse(fromdate);

	}
	log.info("Please enter To date(FORMAT:YYYY-MM-DD)");
	String todate = sc.next();
	while (!Factory.getInputValidationInstance().bookingDateValidation(todate)) {
		log.error("Please enter valid date(FORMAT:YYYY-MM-DD)");
		todate = sc.next();
	}

	LocalDate toDate = LocalDate.parse(todate);
	if (toDate.isBefore(fromDate)) {
		log.info("please enter a valid Date");
		todate = sc.next();
		while (!Factory.getInputValidationInstance().bookingDateValidation(todate)) {
			log.info("Please enter valid date in the format  YYYY-MM-DD");
			todate = sc.next();
		}
		toDate = LocalDate.parse(todate);

	}
		log.info("Please enter your name");
		String name = sc.next();
		while (!Factory.getInputValidationInstance().bookingNameValidation(name)) {
			log.error("Please enter valid  name(Name must contain firstname) ");
			name = sc.next();
		}

		log.info("Please enter your address");
		String address = sc.next();
		while (!Factory.getInputValidationInstance().hotelAddressValidation(address)) {
			log.error("Please enter valid  address(Address must contain City and State)");
			address = sc.next();
		}

		log.info("Please enter email");

		String email = sc.next();
		while (!Factory.getInputValidationInstance().emailValidation(email)) {
			log.error("Please enter valid  email(Email must contain @ . )");
			email = sc.next();
		}

		log.info("Please enter contact number");
		String contactNumber = sc.next();
		while (!Factory.getInputValidationInstance().hotelContactNumberValidation(contactNumber)) {
			log.error("Please enter valid contact number(Contact Number must 10 digits)");
			contactNumber = sc.next();
		}

		Long contactNumber1 = Long.parseLong(contactNumber);

		log.info("Please enter room number");
		String roomNum = sc.next();
		while (!Factory.getInputValidationInstance().roomNumberValidation(roomNum)) {
		log.info("please enter valid number of room num");
		roomNum = sc.next();
		}
		int roomNum1 = Integer.parseInt(roomNum);

		log.info("Please enter room type(1.single 2.double)");
		String roomType = sc.next();
		while (!Factory.getInputValidationInstance().roomTypeValidation(roomType)) {
			log.info("please enter valid room type");
			roomType = sc.next();
		}
		

		log.info("Please enter payment method(1.card 2.upi id 3.wallet)");
		String paymentMethod = sc.next();
		while (!Factory.getInputValidationInstance().nameValidation(paymentMethod)) {
			log.info("please enter valid payment method");
			paymentMethod = sc.next();
		}
		

		booking.setFromDate(fromDate);
		booking.setToDate(toDate);
		booking.setName(name);
		
		booking.setAddress(address);
		booking.setEmail(email);
		booking.setContactNumber(contactNumber1);
		booking.setRoomNum(roomNum1);
		booking.setRoomType(roomType);

		booking.setPaymentMethod(paymentMethod);

		ArrayList<Booking> list = new ArrayList<Booking>();
		list.add(booking);
		bookList.addAll(list);
		if (list.isEmpty()) {
			log.error("Booking failed");
			log.info("please try again");
			return false;
		} else {
			log.info("************Booking Successful************");
			log.info("Booking Details:\n "+booking.toString());
			return true;
		}
	}

public boolean BookingHotel() {

log.info("***********************Booking For Hotel***********************\n");

do {
	log.info(" Please select, which hotel you want to book ?");
	Factory.getAdminDaoImplInstance().listOfHotels();
	log.info(" Please enter hotel name\n");
	String hotelName = sc.nextLine();
	while (!Factory.getInputValidationInstance().hotelNameValidation(hotelName)) {
		log.error("Please enter valid hotel name (Hotel Name should contain name and hotel)");
		hotelName = sc.nextLine();
	}
	addBooking(Factory.getBookingInstance());
	
			return true;
	}while(true);
}

public List<Booking> getBookingDetailsForSpecificHotel(String hotelName) {
	for (Booking booking : bookList) {
		if (booking.getHotelName().equals(hotelName)) {
			List<Booking> searchBooking = new ArrayList<Booking>();
			searchBooking.add(booking);
			log.info("\n\n" + searchBooking + "\n");
		}
	}
	return bookList;
}


	
}
