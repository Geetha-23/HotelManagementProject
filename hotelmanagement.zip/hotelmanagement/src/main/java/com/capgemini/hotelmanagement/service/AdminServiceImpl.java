package com.capgemini.hotelmanagement.service;

import com.capgemini.hotelmanagement.dao.AdminLoginDao;
import com.capgemini.hotelmanagement.factory.Factory;

public class AdminServiceImpl implements AdminService{

	
	public boolean adminService() {
		AdminLoginDao adminDao=Factory.getLoginDaoImplInstance();
		adminDao.adminLogin();
		return false;
	}

}
