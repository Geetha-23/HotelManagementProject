package com.capgemini.hotelmanagement.exception;

public class EmployeeDetailsNotFoundException extends Exception{
	
		String message = " Employee ID is not found  ";

		public String exceptionMessage() {
			return message;
}
	}
