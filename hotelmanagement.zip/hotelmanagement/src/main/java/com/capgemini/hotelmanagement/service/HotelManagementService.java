package com.capgemini.hotelmanagement.service;

public interface HotelManagementService {
public boolean hotelManagementService();
}
