package com.capgemini.hotelmanagement.dao;

import com.capgemini.hotelmanagement.bean.HotelManagementLogin;

public interface HotelManagementDao {

	public boolean getEmployeeLogin();
	
	public boolean employeeOperations();
	

		
		
	}
	
