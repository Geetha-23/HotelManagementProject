package com.capgemini.hotelmanagement.service;

public interface AdminService {
public boolean adminService();
}
