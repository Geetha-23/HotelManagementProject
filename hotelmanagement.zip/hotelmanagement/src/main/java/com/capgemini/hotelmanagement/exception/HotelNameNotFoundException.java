package com.capgemini.hotelmanagement.exception;

public class HotelNameNotFoundException extends Exception{
	public HotelNameNotFoundException() {

	}
}
