package com.capgemini.hotelmanagement.service;

import com.capgemini.hotelmanagement.controller.HotelController;

import com.capgemini.hotelmanagement.dao.CustomerLoginDao;
import com.capgemini.hotelmanagement.factory.Factory;
import org.apache.log4j.*;
public class CustomerLoginServiceImpl implements CustomerLoginService{
static final Logger log=Logger.getLogger(HotelController.class);
CustomerLoginDao customerlogindao=Factory.getLoginDaoInstance();
public boolean customerLginService() {
	customerlogindao.login();
	return true;
	
}
}
