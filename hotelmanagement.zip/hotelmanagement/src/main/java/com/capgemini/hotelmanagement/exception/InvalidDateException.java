package com.capgemini.hotelmanagement.exception;

public class InvalidDateException extends Exception{
public InvalidDateException() {
	
}
}
