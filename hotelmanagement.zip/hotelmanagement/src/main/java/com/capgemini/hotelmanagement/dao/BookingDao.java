package com.capgemini.hotelmanagement.dao;

import java.time.LocalDate;

import java.util.List;

import com.capgemini.hotelmanagement.bean.Booking;

public interface BookingDao {

	public boolean BookingHotel() ;
	public Booking getBookingDetailsForSpecificDate(LocalDate bookingDate);

	public List<Booking> getBookingDetails();

	

	public List<Booking>  getBookingDetailsForSpecificHotel( String hotelName);

	public boolean addBooking(Booking booking);
}
