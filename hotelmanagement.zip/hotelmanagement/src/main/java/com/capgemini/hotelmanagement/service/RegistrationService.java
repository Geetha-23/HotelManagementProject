package com.capgemini.hotelmanagement.service;

public interface RegistrationService {
public boolean registerService();
}
