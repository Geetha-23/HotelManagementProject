package com.capgemini.hotelmanagement.exception;

public class CustomerNameNotFound {
	String message = " Customer name is not found  ";

	public String exceptionMessage() {
		return message;
}
}
