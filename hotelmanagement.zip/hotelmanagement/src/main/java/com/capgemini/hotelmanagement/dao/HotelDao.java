package com.capgemini.hotelmanagement.dao;

import java.util.List;


import com.capgemini.hotelmanagement.bean.Hotel;

public interface HotelDao {
	

	public boolean addHotel();

	public boolean deleteHotel(String hotelName);

	public boolean updateHotel(Hotel hotel1);

	public List<Hotel> getAllHotelDetails();
}
