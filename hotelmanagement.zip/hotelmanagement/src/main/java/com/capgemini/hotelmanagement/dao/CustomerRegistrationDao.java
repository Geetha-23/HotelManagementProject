package com.capgemini.hotelmanagement.dao;

import java.util.List;


import com.capgemini.hotelmanagement.bean.CustomerRegistration;

public interface CustomerRegistrationDao {

	public boolean register(CustomerRegistration customerRegistration);
	public List<CustomerRegistration> getAllCustomers();
	
	}
