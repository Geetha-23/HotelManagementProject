package com.capgemini.hotelmanagement.dao;

public interface CustomerLoginDao {
public boolean login();
public boolean customerOperations();

}
