package com.capgemini.hotelmanagement.dao;

import java.util.ArrayList;



import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.bean.CustomerRegistration;
import com.capgemini.hotelmanagement.exception.CustomerNotFoundException;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.validation.InputValidation;




public class CustomerRegistrationDaoImpl implements CustomerRegistrationDao {
	static final Logger log = Logger.getLogger(CustomerRegistrationDaoImpl.class);
	int count = 0;
	InputValidation inputValidations = null;
	static List<CustomerRegistration> customer = new ArrayList<CustomerRegistration>();
	static int size;
	Scanner sc1 = new Scanner(System.in);
	InputValidation inputValidation = Factory.getInputValidationInstance();
	static {

		CustomerRegistration customer1 = Factory.getCustomerRegistration();
		
		customer1.setUsername("sri");
		customer1.setPassword("Sri@123");
		customer1.setPhno(6281296092l);
		customer1.setMailId("sri@gmail.com");
		customer1.setAge(23);

		CustomerRegistration customer2 = Factory.getCustomerRegistration();
		
		customer2.setUsername("sai123");
		customer2.setPassword("Sai@123");
		customer2.setPhno(9676046365l);
		customer2.setMailId("sai@gmail.com");
		customer2.setAge(25);

		CustomerRegistration customer3 = Factory.getCustomerRegistration();
		
		customer3.setUsername("banu123");
		customer3.setPassword("banuS@123$");
		customer3.setPhno(9700200787l);
		customer3.setMailId("banu@gmail.com");
		customer3.setAge(24);

		customer.add(customer1);
		customer.add(customer2);
		customer.add(customer3);
		size = customer.size();
		
	}

	public boolean register(CustomerRegistration customerRegistration) {
		InputValidation inputValidation = Factory.getInputValidationInstance();
		CustomerRegistration cr = Factory.getCustomerRegistration();
		

		
		log.info("Enter username");
		String username = sc1.next();
		while (!inputValidation.usernameValidation(username)) {
			log.info("please enter valid username(Name must contain firstname and lastname)");
			username = sc1.next();
		}

		log.info("Enter password");
		String password = sc1.next();
		while (!inputValidation.passwordValidation(password)) {
			log.info("please enter valid password");
			password = sc1.next();
		}

		log.info("Enter phno");
		String phone = sc1.next();
		while (!inputValidation.phnoValidation(phone)) {
			log.info("please enter valid phno (Contact Number must 10 digits and start with 7-9 digit only) ");
			phone = sc1.next();
		}
		long phno = Long.parseLong(phone);

		log.info("Enter mailId");
		String mailid = sc1.next();
		while (!inputValidation.emailValidation(mailid)) {
			log.info("please enter valid mailid (Email must contain @ . )");
			mailid = sc1.next();
		}
		log.info("Enter your age");
		String age1 = sc1.next();
		while (!inputValidation.ageValidation(age1)) {
			log.info("please enter valid age");
			age1= sc1.next();
		}

		
		int age = Integer.parseInt(age1);
		cr.setUsername(username);
		cr.setPhno(phno);
		cr.setAge(age);
		cr.setMailId(mailid);
		cr.setPassword(password);

		ArrayList<CustomerRegistration> list = new ArrayList<CustomerRegistration>();

		list.add(cr);
		customer.addAll(list);
		if (list.isEmpty()) {
			log.info("customer details not added \n");
			return false;
		} else {
			log.info("customer details added successfully \n");

			return true;

		}
	}

	public List<CustomerRegistration> getAllCustomers() {
		log.info("list of Customers");
		
		for (int i = 0; i < customer.size(); i++) {
			log.info("\n"+ customer.get(i));
		}
		return customer;
	
	}

	


	}