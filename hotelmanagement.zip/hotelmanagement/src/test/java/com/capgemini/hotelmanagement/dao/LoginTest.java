package com.capgemini.hotelmanagement.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;


import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.bean.AdminLogin;
import com.capgemini.hotelmanagement.bean.CustomerRegistration;
import com.capgemini.hotelmanagement.bean.HotelManagementLogin;
import com.capgemini.hotelmanagement.factory.Factory;



public class LoginTest {
	static final Logger log = Logger.getLogger(LoginTest.class);
	Scanner scanner = new Scanner(System.in);

	@Test
	@DisplayName("Admin Login")
	void testadminLoginTest() {

		log.info("\n\n ****************Test Case for Admin Login****************\n");
		AdminLogin admin = Factory.getAdminInstance();
		admin.setUsername("admin");
		admin.setPassword("admin");

		log.info("Please enter your login details");
		log.info("Admin Username : ");
		String username = scanner.nextLine();
		assertEquals(username, admin.getUsername());

		log.info("\n\n Admin Password : ");
		String password = scanner.nextLine();
		assertEquals(password, admin.getPassword());
	}

	@Test
	@DisplayName("Employee Login")
	void testemployeeLoginTest() {

		log.info("Test Case for Employee Login");
		HotelManagementLogin hotelManagement = Factory.getHotelManagementLoginInstance();
		hotelManagement.setUsername("sri");
		hotelManagement.setPassword("Sri@123");

		log.info("Please enter your login details");
		log.info("Username : ");
		String username = scanner.nextLine();
		assertEquals(username, hotelManagement.getUsername());

		log.info("Password : ");
		String password = scanner.nextLine();
		assertEquals(password, hotelManagement.getPassword());
	}

	@Test
	@DisplayName("Customer Login")
	void testcustomerLoginTest() {

		log.info("Test Case for Customer Login");
		CustomerRegistration customer = Factory.getCustomerRegistration();
		customer.setUsername("sri");
		customer.setPassword("Sri@123");

		log.info("Please enter your login details");
		log.info("Customer Username : ");
		String username=scanner.nextLine();
				assertEquals(username, customer.getUsername());

		log.info("Customer Password : ");
		String password = scanner.nextLine();
				assertEquals(password, customer.getPassword());
	}
}
