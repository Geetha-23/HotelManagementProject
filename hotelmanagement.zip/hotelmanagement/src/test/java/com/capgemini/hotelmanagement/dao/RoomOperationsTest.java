package com.capgemini.hotelmanagement.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;


import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.bean.RoomDetails;
import com.capgemini.hotelmanagement.factory.Factory;



public class RoomOperationsTest {
	static Logger log=Logger.getLogger(RoomOperationsTest.class);


    @Test
    @DisplayName("Add Room")
    void testAddRoom(){
	RoomDetailsDaoImpl roomoperations=Factory.getRoomDaoImplInstance();
	assertEquals(false,roomoperations.addRoom());
}
    @Test
    @DisplayName("Delete Room")
    void testDeleteRoom(){
   RoomDetailsDaoImpl roomoperations=Factory.getRoomDaoImplInstance();
	assertEquals(false,roomoperations.deleteRoom("192"));
}
    @Test
    @DisplayName("update Room")
    void testUpdateRoom(){
   	 
	RoomDetailsDaoImpl roomoperations=Factory.getRoomDaoImplInstance();
	RoomDetails room = Factory.getRoomInstance();
    assertEquals(false,roomoperations.updateRoom(room));
}
}
