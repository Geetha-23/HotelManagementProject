package com.capgemini.hotelmanagement.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;


import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.factory.Factory;



public class CustomerLoginTest {
	static Logger log=Logger.getLogger(CustomerRegistrationDaoImplTest.class);
	@Test
	@DisplayName("customer login")
	void LoginTest() {
		CustomerLoginDao logindao=Factory.getLoginDaoInstance();
		assertEquals(true,logindao.login());
	} 
	
	@Test
	@DisplayName("customer login invalid")
	void LoginTests() {
		CustomerLoginDao logindao=Factory.getLoginDaoInstance();
		assertEquals(false,logindao.login());
	}

}
