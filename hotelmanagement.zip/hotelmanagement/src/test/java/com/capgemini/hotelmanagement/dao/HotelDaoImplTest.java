package com.capgemini.hotelmanagement.dao;

import static org.junit.jupiter.api.Assertions.*;


import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.bean.Hotel;
import com.capgemini.hotelmanagement.factory.Factory;



class HotelDaoImplTest {

	static final Logger log = Logger.getLogger(HotelDaoImpl.class);
	Hotel hotel = Factory.getHotelInstance();

	@Test
	@DisplayName("Add New Hotel")
	void testAddHotel() {
		log.info(" ****************Test Case for Add New Hotel****************\n");
		HotelDao hotelDAO = Factory.getHotelDaoImplInstance();
		assertEquals(true, hotelDAO.addHotel());
	}

	@Test
	@DisplayName("Delete Hotel")
	void testDeleteHotel() {
		log.info("****************Test Case for Delete Hotel****************\n");
		HotelDao hotelDAO = Factory.getHotelDaoImplInstance();
		assertEquals(false, hotelDAO.deleteHotel("Milan Hotel"));
	}

	@Test
	@DisplayName("Update Hotel")
	void testUpdateHotel() {
		log.info(" ****************Test Case for Update Hotel****************\n");
		HotelDao hotelDAO = Factory.getHotelDaoImplInstance();
		assertEquals(false, hotelDAO.updateHotel(hotel));
	}

	@Test
	@DisplayName("Get All Hotel Details")
	void testGetAllHotelDetails() {
		log.info("****************Test Case for Get All Hotel Details****************\n");
		HotelDao hotelDAO = Factory.getHotelDaoImplInstance();
		assertNotNull(hotelDAO.getAllHotelDetails());
	}
}
