package com.capgemini.hotelmanagement.dao;

import static org.junit.jupiter.api.Assertions.*
;

import java.time.LocalDate;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.bean.Booking;
import com.capgemini.hotelmanagement.factory.Factory;



 public class BookingDaoImplTest {

	static final Logger log = Logger.getLogger(BookingDaoImpl.class);
	Booking booking = Factory.getBookingInstance();

	@Test
	@DisplayName("Add Booking")
	void testAddBooking() {
		log.info("\n\n ****************Test Case for Add Booking****************\n");
		BookingDao bookingdao = Factory.getBookingDaoImplInstance();
		assertEquals(true, bookingdao.addBooking(booking));
	}

	@Test
	
	@DisplayName("Get Booking Details")
	void testGetBookingDetails() {
		log.info("\n\n ****************Test Case for Get Booking Details****************\n");
		BookingDao bookingDAO = Factory.getBookingDaoImplInstance();
		assertNotNull(bookingDAO.getBookingDetails());
	}

	@Test
	@DisplayName("Booking Details for Specific Date")
	void testBookingDetailsForSpecificDate() {
		log.info("\n\n ****************Test Case for Booking Details of Specific Date****************\n");
		BookingDao bookingDAO = Factory.getBookingDaoImplInstance();
		assertNotNull(bookingDAO.getBookingDetailsForSpecificDate(LocalDate.of(2020, 04, 25)));
	}
	
	@Test
	@DisplayName("Booking Details for Specific Hotel")
	void testBookingDetailsForSpecificHotel() {
		log.info("\n\n ****************Test Case for Booking Details of Specific Hotel****************\n");
		BookingDao bookingDAO = Factory.getBookingDaoImplInstance();
		assertNotNull(bookingDAO.getBookingDetailsForSpecificHotel("Milan Hotel"));
	}
}
