package com.capgemini.hotelmanagement.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.bean.CustomerRegistration;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.validation.InputValidation;

public class CustomerRegistrationDaoImplTest {
	static final Logger log = Logger.getLogger(CustomerRegistrationDaoImpl.class);

	Scanner scanner = new Scanner(System.in);
	InputValidation inputValidation = Factory.getInputValidationInstance();
	CustomerRegistration customerRegister = Factory.getCustomerRegistrationInstance();

	@Test
	@DisplayName("Customer Account Exist or Not")
	void testcustomerRegistrationTest() {

		log.info("\n\n ****************Test Case for Customer Account Exist or Not****************\n");

		customerRegister.setUsername("sri");
		customerRegister.setPassword("Sri@123");
		customerRegister.setMailId("sri@gmail.com");
		customerRegister.setPhno(9700200787l);
		customerRegister.setAge(23);
		

		log.info(" ***********************Please enter your details***********************\n");

		log.info(" Please enter your name\n");
		String name = scanner.nextLine();
		while (!inputValidation.nameValidation(name)) {
			log.error("Please enter valid  name (Name must contain firstname and lastname) ");
			name = scanner.nextLine();
		}
		assertEquals(name, customerRegister.getUsername());

		log.info("Please enter email\n");
		String email = scanner.nextLine();
		while (!inputValidation.emailValidation(email)) {
			log.error("Please enter valid  email (Email must contain @ . )");
			email = scanner.nextLine();
		}
		assertEquals(email, customerRegister.getMailId());

		log.info("Please enter contact number\n");
		String contactNumber = scanner.nextLine();
		while (!inputValidation.phnoValidation(contactNumber)) {
			log.error(
					"Please enter valid contact number (Contact Number must 10 digits and start with 7-9 digit only) ");
			contactNumber = scanner.nextLine();
		}
		Long contactNumber1 = Long.parseLong(contactNumber);
		assertEquals(contactNumber1, customerRegister.getPhno());

		log.info("Please enter username\n");
		String username = scanner.nextLine();
		while (!inputValidation.usernameValidation(username)) {
			log.error("Please enter valid  username (Username may contain alphabets, number, - , _");
			username = scanner.nextLine();
		}
		assertEquals(username, customerRegister.getUsername());

		log.info("Please enter password\n");
		String password = scanner.nextLine();
		while (!inputValidation.passwordValidation(password)) {
			log.error(
					"Please enter valid  password (Password must contain atleast one lowercase letter, uppercase letter, digit and special character and legth should be 6-16");
			password = scanner.nextLine();
		}
		assertEquals(password, customerRegister.getPassword());
	}

	@Test
	@DisplayName("Add Customer")
	void testAddCustomer() {
		log.info(" ****************Test Case for Add New Customer****************\n");
		CustomerRegistrationDao customerRegistrationDAO = Factory.getCustomerRegistrationDAOImplementationInstance();
		assertEquals(true, customerRegistrationDAO.register(customerRegister));
	}

}
